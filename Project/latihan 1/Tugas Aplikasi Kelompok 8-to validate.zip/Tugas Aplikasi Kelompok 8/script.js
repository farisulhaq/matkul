const order = document.querySelector('.order-btn');
const nama = document.querySelector('#user');
const email = document.querySelector('#email');
const modal = document.querySelector('.modal')
const overlay = document.querySelector('.overlay');
const body = document.querySelector('body');

function showModal(){
	order.addEventListener('click',function(){
		let paragraph = document.querySelector('.congrats');
		paragraph.innerHTML = `Terimakasih telah memesan <b>${nama.value}</b>, silahkan cek email anda di <i>${email.value}</i> untuk informasi lebih lanjut`;
		body.style.overflow = 'hidden';
		modal.style.visibility = 'visible';
		overlay.style.visibility = 'visible';
	});
}
showModal();


